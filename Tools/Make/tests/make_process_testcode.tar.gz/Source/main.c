/*
 * This file is part of the test code for make process development.
 *
 * It might on purpose contain errors and does not comply with any coding
 * guideline.
 */

#include <stdio.h>
#include "qac_bl_header.h"

static int tessy_function(int a, int b);

int main(void)
{
    printf("Hello, world!\n");

    return tessy_function(0, 0);
}

/* Empty function produces QA-C metric violation 6170 - STST3 = 0 (number of
 * statements in function). */
void qac_metric_violation(void)
{

}

/* Function to test automatic unit testing. */
static int tessy_function(int a, int b)
{
    return a + b;
}
