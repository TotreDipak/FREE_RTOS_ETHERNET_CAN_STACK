/*
 * This file is part of the test code for make process development.
 *
 * It might on purpose contain errors and does not comply with any coding
 * guideline.
 */

/*
 * This file shall be used to test blacklisting of headers for QA-C / MISRA
 * check.
 */

#ifndef QAC_BL_HEADER_H
#define QAC_BL_HEADER_H

/* MISRA Rule 06.03 Use of basic type int. */
int myfunction(void);

#endif /* QAC_BL_HEADER_H */
