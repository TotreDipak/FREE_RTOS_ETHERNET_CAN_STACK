/*
 * This file is part of the test code for make process development.
 *
 * It might on purpose contain errors and does not comply with any coding
 * guideline.
 */

/*
 * This file is used to test the blacklisting of modules for the c compiler.
 */
#error You tried to compile a module that should be blacklisted.
